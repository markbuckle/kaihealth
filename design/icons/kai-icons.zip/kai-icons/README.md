# Kai Health sidebar icons

24 icons, 24 x 24 px, 1.5 px rounded stroke with a 16% tint of the same colour.

- light/        Text colour #1C1C1B, for the light theme
- dark/         Text colour #FCFCFB, for the dark theme
- currentColor/ Inherits the CSS text colour; use these in code so one file covers both themes and every state

Each file has two paths: the tint (fill-opacity 0.16) and the line (stroke). Paths are optimised with SVGO, coordinates rounded to 2 decimals.

Navigation: summary, areas, plan, records, wearables
Health areas: priorities, heart, inflammation, metabolic, nutrients, liver, hormones, blood, kidney, thyroid, cellular, neural
Action plan: plan-priorities, exercise, nutrition, sleep, lifestyle, screening, followup
